MANZO AI / AI Teaching Lab — un solo ZIP.

1. Per VEDERE il video e le 15 slide originali adesso, estrai questo ZIP e apri ANTEPRIMA_LOCALE.html.
2. Per PUBBLICARLE sul sito, carica l intero ZIP (senza estrarlo) in GitHub, cartella editorial/learning/ai-teaching-lab/media/, branch main.
3. Al termine del deploy il sito leggerà automaticamente video e slide.

Il PDF e il PPTX originali restano disponibili negli allegati separati gia forniti.
