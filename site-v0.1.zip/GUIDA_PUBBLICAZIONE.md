# MANZO AI — Sito statico trilingue per GitHub Pages

**Versione:** 0.1, 27 ottobre 2026  
**Stato:** build locale pronta, pubblicazione GitHub non ancora eseguita  
**Progetto madre:** MARCELUS AI LAB  
**Identità:** logo Manzo geometrico esistente, senza ridisegni

## Cosa contiene

- Home conversazionale, **ricerca locale reale** di contenuti disponibili, nessuna API o chatbot.
- Lezione M01 integrale, da fonte approvata dall'utente, in IT / ES / EN.
- Vocabolario iniziale di 10 concetti, in IT / ES / EN.
- Quiz interattivo nel browser, con feedback e reset.
- Pagine fonti, metodo editoriale, informative essenziali.
- Rotte statiche localizzate, canonical reciproci, hreflang + x-default della pagina di selezione della lingua.
- Sitemap, JSON-LD basato sul contenuto realmente pubblicato, immagine social 1200×630 per lingua, 404, .nojekyll.

**Non inclusi nel sito:** lezioni M02–M06, schede prompt P01–P12 e materiali ancora in revisione del pacchetto 50%. Non sono pubblicati senza approvazione.

## Pubblicazione suggerita (sito autonomo)

1. Creare su GitHub un repository pubblico vuoto **`manzo-ai`** dell'utente `manzo8b` (non selezionare README iniziale).
2. Aprire il repository e caricare il codice sorgente di questa cartella, inclusi `build.py`, `content/`, `style.css`, `logo.svg` e `.github/workflows/pages.yml`.
3. In `Settings → Pages` selezionare come **Source: GitHub Actions**.
4. Il workflow creerà e distribuirà il sito statico `https://manzo8b.github.io/manzo-ai/`.
5. Attendere l'esito del workflow, poi verificare la Home, IT/ES/EN, ricerca, quiz, fonti, SEO e link.

**Alternativa senza build:** copiare il **contenuto** della cartella `dist/` (non la cartella stessa) nella radice del repository. In `Settings → Pages`, usare `Deploy from a branch` → `main` → `/(root)`. Assicurarsi che `.nojekyll` sia presente. Non mescolare le due procedure.

## Rigenerazione locale

Richiede Python 3.12+ e pacchetti `mistune`, `beautifulsoup4`, `pillow`, `cairosvg`.

```bash
python -m pip install -r requirements.txt
python build.py --origin https://manzo8b.github.io --base /manzo-ai --out dist
```

Per un sottosito futuro dentro un repository diverso, modificare `--origin` e `--base` e ricostruire: tutti i canonical, hreflang e link assumono il prefisso configurato.

## Note SEO essenziali

- I caratteri del titolo e della meta description sono indicativi, non vincoli Google.
- `robots.txt` è incluso nella **root del sito distribuito**, ma su un GitHub Pages di tipo project il file si trova di fatto in `/manzo-ai/robots.txt`, **non** nel livello host `manzo8b.github.io/robots.txt`; non attribuirgli un controllo host-wide. La sitemap può essere sottoposta a Search Console tramite la proprietà adatta.
- I dati strutturati `LearningResource` e `DefinedTermSet` descrivono il contenuto e non implicano risultati arricchiti garantiti.
- La pagina di selezione lingue è x-default; le versioni IT, ES, EN includono canonical e alternates reciproci per ogni tipo di pagina.
- Le Core Web Vitals LCP/INP/CLS sono **obiettivi**, non misure di laboratorio verificate in questa build.

## Sicurezza e privacy

Sito statico senza API, analytics, cookie di profilazione, form di raccolta dati, account o storage browser persistente. GitHub può gestire richieste HTTP e dati tecnici secondo la propria informativa. La sezione privacy del sito è una nota trasparente iniziale, da revisionare se cambiano servizi o natura dell'attività.

## Collaudo effettuato

- 22 pagine `index.html`, ognuna con un solo H1.
- Verifica delle rotte e dei link interni, dei canonical e della struttura del sitemap XML.
- Verifica sintattica JavaScript con Node.
- Immagini social generate da logo Manzo esistente.
- **Non** è stato possibile eseguire test automatici Playwright in questa sessione: il browser era soggetto a un blocco amministrativo sulla navigazione. Controllare UI e responsive dopo la pubblicazione, prima di dichiarare la release definitiva.
