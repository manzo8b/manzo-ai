# MANZO AI — Guida alle slide M01 (italiano)

**Codice:** SLIDE-IT-M01-01 · **Stato:** bozza visiva da approvare.
**Formato:** 16:9 · **Destinazione:** aula, proiettore e lezioni online.
**Base:** modulo M01 approvato, conservato senza modifiche.

## Percorso e indicazioni docente

1. **Copertina** — Chiedere quali applicazioni AI il pubblico conosce. Chiarire che AI è un campo più ampio dei chatbot.
2. **Che cos’è l’AI?** — Distinguere input, modello e output; il diagramma è una semplificazione, non descrive tutti i sistemi AI.
3. **AI / ML / deep learning** — I cerchi rappresentano inclusione: il deep learning è un sottoinsieme del machine learning, che è parte dell’AI.
4. **AI generativa** — Discutere contenuti plausibili ma errati: una risposta credibile richiede comunque verifica.
5. **Addestramento e risposta** — **Precisazione obbligatoria:** l’addestramento e l’inferenza sono fasi distinte. Il prompt arriva quando il modello è già addestrato; lo schema mette in sequenza i concetti a scopo divulgativo. La generazione avviene progressivamente e non garantisce correttezza.
6. **Vita e lavoro** — Fare esempi reali e segnalare che singole funzionalità possono essere realizzate anche senza AI.
7. **Esercizio AI o automazione?** — Fare scegliere un’ipotesi e chiedere **quali informazioni servono**. Il timer con orario fisso e lo spostamento di file per regola sono automazioni. **Un chatbot non è necessariamente AI:** dipende da come è costruito. **Le raccomandazioni di film possono basarsi su ML o regole**, quindi l’etichetta da sola non basta. Evitare di presentare 1 e 3 come sicuramente AI. Le etichette grafiche nella slide non sono pulsanti interattivi.
8. **Conclusioni, limiti e fonti** — Rimarcare bias, errori, privacy, verifica umana; invitare a consultare la bibliografia completa della lezione sul sito.

## Fonti per approfondire

- OECD — AI system definition: https://oecd.ai/en/wonk/ai-system-definition
- Google Machine Learning Crash Course: https://developers.google.com/machine-learning/crash-course
- OpenAI Academy: https://openai.com/academy/
- UNESCO AI Competency Framework for Students: https://www.unesco.org/en/articles/ai-competency-framework-students
- NIST AI RMF Generative AI Profile: https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence

**Nota sulle licenze:** rappresentazioni originali MANZO AI; i nomi delle aziende sono riportati per attribuzione documentale, non per indicare affiliazione.
**Nota sul formato:** le immagini nelle slide PPTX sono immagini a pagina intera (non testo modificabile separatamente).
